package ControladorEX;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import ViewEX.ViewExcel;
import ModeloEX.ModeloExcel;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.TableRowSorter;


public class ControladorExcel implements ActionListener{

    ModeloExcel Modelo = new ModeloExcel();
    ViewExcel Vista = new ViewExcel();
    JFileChooser selecArchivo = new JFileChooser();
    File archivo;
    int c = 0;
    private TableRowSorter trs;
    
    public ControladorExcel(ViewExcel vista, ModeloExcel modelo){
        this.Vista = vista;
        this.Modelo = modelo;
        this.Vista.BotonImportar.addActionListener(this);
        this.Vista.BotonExportar.addActionListener(this);
    }
    
    public void AgregarFiltro(){
        selecArchivo.setFileFilter(new FileNameExtensionFilter("Excel (*.xls)", "xls"));
        selecArchivo.setFileFilter(new FileNameExtensionFilter("Excel (*.xlsx)", "xlsx"));
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        c++;
        if(c == 1){
            AgregarFiltro();
        }
        if(e.getSource() == Vista.BotonImportar){
            if(selecArchivo.showDialog(null, "Seleccionar archivo") == JFileChooser.APPROVE_OPTION){
                archivo = selecArchivo.getSelectedFile();
                if(archivo.getName().endsWith("xls") ||archivo.getName().endsWith("xlsx")){
                    JOptionPane.showMessageDialog(null, Modelo.Importar(archivo, Vista.JTableData));
                } else{
                    JOptionPane.showMessageDialog(null, "Elija un formato válido");
                }
            }
        }
        
        if(e.getSource() == Vista.BotonExportar){
            if(selecArchivo.showDialog(null, "Exportar archivo") == JFileChooser.APPROVE_OPTION){
                archivo = selecArchivo.getSelectedFile();
                if(archivo.getName().endsWith("xls") ||archivo.getName().endsWith("xlsx")){
                    JOptionPane.showMessageDialog(null, Modelo.Exportar(archivo, Vista.JTableData));
                } else{
                    JOptionPane.showMessageDialog(null, "Elija un formato válido");
                }
            }
        }
        
    }   
}
