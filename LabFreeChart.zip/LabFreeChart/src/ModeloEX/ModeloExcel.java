package ModeloEX;

import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.xssf.usermodel.*;

public class ModeloExcel {
    Workbook wb;
    TableRowSorter<DefaultTableModel> sorter;
    
    public String Importar(File archivo, JTable tabla){
        String respuesta = "No se pudo realizar la importación";
        
        DefaultTableModel mt = new DefaultTableModel();
        tabla.setModel(mt);
        tabla.setAutoCreateRowSorter(true);
        
        try{
            wb = WorkbookFactory.create(new FileInputStream(archivo));
            Sheet hoja = wb.getSheetAt(0);
            Iterator FilaIterator = hoja.rowIterator();
            int indiceFila = -1;
            while(FilaIterator.hasNext()){
                indiceFila++;
                Row fila = (Row) FilaIterator.next();
                Iterator ColumnaIterator = fila.cellIterator();
                Object[] listaColumna = new Object[100];
                int indiceColumna = -1;
                
                while(ColumnaIterator.hasNext()){
                    indiceColumna++;
                    Cell celda = (Cell) ColumnaIterator.next();
                    if(indiceFila == 0){
                        mt.addColumn(celda.getStringCellValue());
                    } else{
                        if(celda != null){
                            switch(celda.getCellType()){
                                case Cell.CELL_TYPE_NUMERIC:
                                    listaColumna[indiceColumna] = (long) Math.round(celda.getNumericCellValue());
                                    break;
                                case Cell.CELL_TYPE_STRING:
                                    listaColumna[indiceColumna] = celda.getStringCellValue();
                                    break;
                                default:
                                    listaColumna[indiceColumna] = celda.getDateCellValue();
                                    break;
                            }
                        }
                    }
                }
                
                if(indiceFila!=0){
                    mt.addRow(listaColumna);
                }
            }
            
            respuesta = "Importacion exitosa";
        }catch(Exception e){
            return respuesta;
        }
        
        sorter = new TableRowSorter<>(mt);
        tabla.setRowSorter(sorter);
        
        
        return respuesta;
    }
    
    public void filtrar(String txt){
        try {
            sorter.setRowFilter(RowFilter.regexFilter(txt));
        } catch (Exception e) {
        }
    }
    
    public String Exportar(File archivo, JTable tabla){
        String Respuesta = "No se ha realizado con exito la exportacion";        
        int numFilas = tabla.getRowCount(), numColumnas = tabla.getColumnCount();        
        if(archivo.getName().endsWith("xls")){
            wb = new HSSFWorkbook();
        }else{
            wb = new XSSFWorkbook();
        }
        Sheet hoja = wb.createSheet("DataBaseGobierno");
        
        try{
            for(int i = -1; i < numFilas; i++){
                Row fila = hoja.getRow(i+1);
                
                for(int j = 0; j < numColumnas; j++){
                    Cell celda = fila.createCell(j);
                    if(i == -1){
                        celda.setCellValue(String.valueOf(tabla.getColumnName(j)));
                    }else{
                        celda.setCellValue(String.valueOf(tabla.getValueAt(i, j)));
                    }
                    wb.write(new FileOutputStream(archivo));
                }
            }
            Respuesta = "Exportacion exitosa";
        }catch(Exception e){
            
        }
        
        return Respuesta;
    }
}
