package labfreechart;

import ControladorEX.ControladorExcel;
import ModeloEX.ModeloExcel;
import ViewEX.ViewExcel;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class LabFreeChart {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        correr();
    }
    
    public static void correr(){
        ModeloExcel modeloE = new ModeloExcel();
        ViewExcel vistaE = new ViewExcel();
        ControladorExcel contraControladorExcel = new ControladorExcel(vistaE, modeloE);
        vistaE.setVisible(true);
        vistaE.setLocationRelativeTo(null);
    }
}